package com.company;

import java.io.*;
import java.util.*;


public class Main {
    static void display(List<Pegawai> pegawai_list){
        System.out.println("DATA KEPEGAWAIAN\n");
        for (Pegawai peg: pegawai_list
             ) {
            System.out.println(peg.getInfo());
        }
    }
    static void printInorderTraversal(BinaryTree.TreeNode root) {
        if (root != null) {
            printInorderTraversal(root.left);
            System.out.print(root.data + " ");
            printInorderTraversal(root.right);
        }
    }

    static int binarySearch(List<Pegawai> pegawai_list, int low, int high, String nip){
        if(high<low)
            return -1;
        int mid = (low+high)/2;
        if (nip.equals(pegawai_list.get(mid).getNip()))
            return mid;
        if (Integer.parseInt(nip) > Integer.parseInt(pegawai_list.get(mid).getNip()))
            return binarySearch(pegawai_list, (mid+1),high, nip);
        return binarySearch(pegawai_list, low, (mid-1),nip);
    }
    static boolean searchTree(BinaryTree.TreeNode root, int value){
        if(root==null) return false;
        if((int) root.data == value) return true;
        if(value<(int) root.data) return searchTree(root.left, value);
        else if(value>(int) root.data) return searchTree(root.right, value);

        return false;
    }

    static List<Pegawai> delete(List<Pegawai> pegawai_list, String nip){
        int index_pegawai = binarySearch(pegawai_list, 0 , pegawai_list.size()-1,nip);

        if (index_pegawai == -1){
            System.out.println("Data pegawai dengan nip: "+nip+" tidak ditemukan!");
        }
        else{
            System.out.println("Data Pegawai:\n"+pegawai_list.get(index_pegawai).getInfo()+"\nBerhasil dihapus!");
            pegawai_list.remove(index_pegawai);
        }
        return pegawai_list;
    }
    static BinaryTree.TreeNode deleteTree(BinaryTree.TreeNode root, int value){
        if(root==null) return root;
        if(value<(int) root.data){
            root.left=deleteTree(root.left,value);
        }else if(value>(int) root.data){
            root.right=deleteTree(root.right,value);
        }else{
            if(root.left==null){
                return root.right;
            }else if(root.right==null){
                return root.left;
            }
            root.data = inOrderSuccesor(root.right);
            root.right = deleteTree(root.right,(int) root.data);
        }
        return root;
    }
    static int inOrderSuccesor(BinaryTree.TreeNode root){
        int minimum = (int) root.data;
        while (root.left != null){
            minimum = (int) root.left.data;
            root = root.left;
        }
        return minimum;
    }

    static void find(List<Pegawai> pegawai_list, String nip){
        int index_pegawai = binarySearch(pegawai_list, 0 , pegawai_list.size()-1,nip);

        if (index_pegawai == -1){
            System.out.println("Data pegawai dengan nip: "+nip+" tidak ditemukan!");
        }
        else{
            System.out.println("Data Pegawai:\n"+pegawai_list.get(index_pegawai).getInfo());
        }
    }

    static List<Pegawai> binaryInsert(List<Pegawai> data, int low, int high, Pegawai pegawai_inserted) {
        if (high < low){
            data.add(low,pegawai_inserted);
            return data;
        }

        int mid = (low + high) / 2;
        if (Integer.parseInt(pegawai_inserted.getNip()) > Integer.parseInt(data.get(mid).getNip()))
            return binaryInsert(data, (mid + 1), high, pegawai_inserted);
        return binaryInsert(data, low, (mid - 1), pegawai_inserted);
    }
    public static BinaryTree.TreeNode insertionTree(BinaryTree.TreeNode root, int value){
        BinaryTree.TreeNode current, parent;
        BinaryTree.TreeNode tempNode = new BinaryTree.TreeNode(value);

        if (root==null){
            root = tempNode;
            return root;
        }else{
            current=root;
        }
        while(true){
            parent = current;

            if(value<(int)current.data){
                current = current.left;
                if(current==null){
                    parent.left=tempNode;
                    return root;
                }
            }else if(value>(int) current.data){
                current = current.right;
                if(current==null){
                    parent.right = tempNode;
                    return root;
                }
            }
        }
    }

    static List<Pegawai> updateGaji(List<Pegawai> pegawai_list,String nip, String gaji){
        int index_pegawai = binarySearch(pegawai_list, 0 , pegawai_list.size()-1,nip);
        if(index_pegawai == -1){
            System.out.println("Data pegawai dengan nip: "+nip+" tidak ditemukan!");
           return pegawai_list;
        }
        else{
            System.out.println("Data pegawai dengan nip: "+nip+" berhasil diupdate!");
            pegawai_list.get(index_pegawai).setGaji(gaji);
            return pegawai_list;
        }
    }
    static List<Pegawai> updateMasa(List<Pegawai> pegawai_list,String nip, String masa){
        int index_pegawai = binarySearch(pegawai_list, 0 , pegawai_list.size()-1,nip);

        if(index_pegawai == -1){
            System.out.println("Data pegawai dengan nip: "+nip+" tidak ditemukan!");
            return pegawai_list;
        }
        else{
            System.out.println("Data pegawai dengan nip: "+nip+" berhasil diupdate!");
            pegawai_list.get(index_pegawai).setMasa(masa);
            return pegawai_list;
        }
    }
    static Integer getTotalGaji(List<Pegawai> pegawaiList){
        Integer total = 0;
        for(int i=0;i<pegawaiList.size();i++){
            total = total + Integer.parseInt(pegawaiList.get(0).getGaji());
        }
        return total;
    }

    public static void main(String[] args){

        List<List<String>> data_urut_nip = new ArrayList<>();
        try(BufferedReader br = new BufferedReader(new FileReader("resources/data_pegawai.txt"))){
            String line;
            while ((line = br.readLine())!=null){
                String[] values = line.split(",");
                    data_urut_nip.add(Arrays.asList(values));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        data_urut_nip.sort(Comparator.comparing(l -> l.get(1)));
        List<Pegawai> pegawai_list = new ArrayList<>();
        BinaryTree tree = new BinaryTree();

        for (List data:data_urut_nip
             ) {
            Pegawai pegawai = new Pegawai();
            pegawai.setNama((String) data.get(0));
            pegawai.setNip((String) data.get(1));
            pegawai.setMasa((String) data.get(2));
            pegawai.setGaji((String) data.get(3));
            pegawai_list.add(pegawai);
            //memasukkan data nip ke dalam BST
            tree.root = insertionTree(tree.root, Integer.parseInt(pegawai.getNip()) );
        }



        Scanner scanner = new Scanner(System.in);
        printInorderTraversal(tree.root);
        System.out.println("\nSELAMAT DATANG DI SISTEM KEPEGAWAIAN\n");
        int pilihan = 1;
        while(pilihan!=0){
            System.out.println("_____________________________\nPilih Menu:");
            System.out.println(
                    "1. Insert()\n" +
                    "2. Delete()\n" +
                    "3. Find()\n" +
                    "4. Display()\n" +
                    "5. UpdateGaji()\n" +
                    "6. UpdateMasaKerja()\n" +
                    "7. GetTotalGaji()\n" +
                    "0. Selesai\n");
            System.out.print("_____________________________\nMasukkan nomor pilihan: ");
            pilihan = scanner.nextInt();
            scanner.nextLine();
            switch (pilihan){
                case 1:
                    Pegawai pegawai = new Pegawai();
                    System.out.println("Masukkan nama: ");
                    String nama = scanner.nextLine();
                    pegawai.setNama(nama);
                    System.out.println("Masukkan NIP: ");
                    String nipnya = scanner.next();
                    pegawai.setNip(nipnya);
                    System.out.println("Masukkan masa: ");
                    String masanya = scanner.next();
                    pegawai.setMasa(masanya);
                    System.out.println("Masukkan gaji: ");
                    String gajinya = scanner.next();
                    pegawai.setGaji(gajinya);
                    if(binarySearch(pegawai_list, 0 , pegawai_list.size()-1,pegawai.getNip())!=-1){
                        System.out.println("NIP sudah terdaftar!");
                        break;
                    }
                    binaryInsert(pegawai_list,0,pegawai_list.size()-1,pegawai);

                    //memasukkan data nip ke dalam BST
                    tree.root = insertionTree(tree.root, Integer.parseInt(pegawai.getNip()));

                    System.out.println("Data pegawai dengan NIP: "+pegawai.getNip()+" berhasil dimasukkan!");
                    break;
                case 2:
                    System.out.println("Masukkan NIP: ");
                    String nipHapus = scanner.next();
                    pegawai_list = delete(pegawai_list,nipHapus);

                    //menghapus data nip pada BST
                    tree.root = deleteTree(tree.root, Integer.parseInt(nipHapus));
                    break;
                case 3:
                    System.out.println("Masukkan NIP: ");
                    String case3 =scanner.next();
                    //mencari data nip pada BST
                    if(searchTree(tree.root, Integer.parseInt(case3))){
                        find(pegawai_list, case3);
                    }else{
                        System.out.println("Data dengan NIP: "+case3+" tidak ditemukan!");
                    }
                    break;
                case 4:
                    display(pegawai_list);
                    break;
                case 5:
                    System.out.println("Masukkan NIP dan Gaji: ");
                    pegawai_list = updateGaji(pegawai_list,scanner.next(),scanner.next());
                    break;
                case 6:
                    System.out.println("Masukkan NIP dan Masa Kerja: ");
                    pegawai_list = updateMasa(pegawai_list, scanner.next(),scanner.next());
                    break;
                case 7:
                    System.out.println("Total gaji seluruh pegawai: "+getTotalGaji(pegawai_list));
                    break;
                case 0:
                    System.out.println("Terima kasih. Aplikasi menutup ...");
                    break;
                default:
                    System.out.println("Nomor yang anda masukkan salah. Aplikasi menutup ...");
                    pilihan = 0;
            }

        }
    }
}
